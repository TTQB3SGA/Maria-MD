<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
## 𝐁𝐄𝐋𝐓𝐀𝐇-𝐌𝐃 V5.0.0 𝐋𝐀𝐓𝐄𝐒𝐓
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
## 𝐏𝐎𝐖𝐄𝐑𝐄𝐃 𝐁𝐘 𝐁𝐄𝐋𝐓𝐀𝐇 𝐓𝐄𝐂𝐇
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<div align="center">
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=910&height=100&lines=𝗕𝗘𝗟𝗧𝗔𝗛+𝗠𝗗;A+WHATSAPP+BOT;CREATED+BY+BELTAH+TECH" alt="Typing SVG" /></a>
  </p>
<div align="center">

| [![Beltah KE](https://telegra.ph/file/dcce2ddee6cc7597c859a.jpg?lenght=50width=50)](https://github.com/Beltahtech)|
|----|

<p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=d1fa02&center=true&vCenter=true&multiline=false&lines=BELTAH-MD+Is+Safe+on+Heroku" alt="">
</p>
<p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-BELTAH TECH-red.svg?style=for-the-badge&logo=github"></a>
<p/>
<p align="center">
<a href="https://github.com/Beltah-MD? tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/Beltahtech?label=Followers&style=social"></a>
<a href="https://github.com/Beltahtech/Beltah-MD/stargazers/"><img title="STARS" src="https://img.shields.io/github/stars/Beltahtech/Beltah-MD?&style=social"></a>
<a href="https://github.com/Beltahtech/Beltah-MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Beltahtech/Beltah-MD?style=social"></a>
<a href="https://github.com/Beltatech/Beltah-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Beltahtech/Beltah-MD?label=Watching&style=social"></a>

  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  
  ## MUST FOLLOW OUR OFFICIAL CHANNEL
<a href="https://whatsapp.com/channel/0029VaRHDBKKmCPKp9B2uH2F" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/ Whatsapp Support Channel -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## SETUP FOR 𝗕𝗘𝗟𝗧𝗔𝗛 𝗠𝗗

  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  
**CLICK HERE 👇 TO FORK**

<a href="https://github.com/Beltahtech/Beltah-MD/fork"><img src="https://img.shields.io/badge/Fork%20Beltah-MD%20Repo-blue" alt="FORK BELTAH-MD REPO" width="150"></a>

  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## GET YOUR SESSION ID: 

  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  
**CLICK HERE 👇 TO PAIR**

<a href="https://beltah-bot-054eec74e93f.herokuapp.com/pair"><img src="https://img.shields.io/badge/Pair%20session%20code-green" alt="𝐏𝐚𝐢𝐫 𝐬𝐞𝐬𝐬𝐢𝐨𝐧 𝐜𝐨𝐝𝐞" width="150"></a>

  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

**CLICK HERE 👇 TO SCAN QR**

<a href="https://beltah-bot-054eec74e93f.herokuapp.com/qr"><img src="https://img.shields.io/badge/QR%20session%20code-red" alt="𝐐𝐫 𝐬𝐞𝐬𝐬𝐢𝐨𝐧 𝐜𝐨𝐝𝐞" width="150"></a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## 4.DEPLOY BELTAH-MD V5.0.0
(No BAN)
<h1 align="center">
 
 ***[![DEPLOY NOW ON HEROKU](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?button-url=https://github.com/Beltahtech/Beltah-MD&template=https://github.com/Beltahtech/Beltah-MD.git)***

 <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## DEPLOY ANY BOT OF YOUR CHOICE

<a href="https://github.com/IBRAHIM-TECH-AI/DEPLOYMENT-SITE/tree/main"><img title="Deploy the bot of your choice" src="https://img.shields.io/badge/DEPLOY ANY BOT-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

 ## CONTACT DEVELOPER ON WHATSAPP 
 
<a href="https://wa.me/254114141192" target="_blank">
    <img alt="whatsapp Group" src="https://img.shields.io/badge/ Beltah Tech contact -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a> 
</p>

## CONTRIBUTIONS

Contributions to BELTAH-MD are welcome! If you have ideas for new features, improvements, or bug fixes, feel free to open an issue or submit a pull request. <br>

## License

The WhatsApp Bot 𝗕𝗘𝗟𝗧𝗔𝗛 𝗠𝗗 is released under the [MIT License](https://opensource.org/licenses/MIT).

🌟 THANK YOU FOR CHOOSING BELTAH-MD 🌟

## THANKS TO :

- [**BELTAH TECH**](https://github.com/Beltahtech)

Beltahtech ©2024
