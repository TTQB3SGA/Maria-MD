"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const { zokou } = require("../framework/zokou");
zokou({ nomCom: "wagroup", reaction: "😌", nomFichier: __filename }, async (dest, zk, commandeOptions) => {
    console.log("Commande saisie !!!s");
    let z = '𝐁𝐄𝐋𝐓𝐀𝐇-𝐌𝐃 𝐕𝟒.𝟎.𝟎 𝐋𝐀𝐓𝐄𝐒𝐓\n\n👋Hello,,Click The link below to Join 𝐁𝐄𝐋𝐓𝐀𝐇-𝐌𝐃 WhatsApp Testing Group\n\n';
    let d = 'https://chat.whatsapp.com/CQvUnqaDK4fBjgMXvFEAsI\n\nJoin the group and wait for updates from the admin,Thank you. \n\n\n> 𝐏𝐎𝐖𝐄𝐑𝐄𝐃 𝐁𝐘 𝐁𝐄𝐋𝐓𝐀𝐇 𝐓𝐄𝐂𝐇';
    let varmess = z + d;
    var img = 'https://telegra.ph/file/dcce2ddee6cc7597c859a.jpg';
    await zk.sendMessage(dest, { image: { url: img }, caption: varmess });
    //console.log("montest")
});
console.log("mon test");

zokou({ nomCom: "channel", reaction: "😌", nomFichier: __filename }, async (dest, zk, commandeOptions) => {
    console.log("Commande saisie !!!s");
    let z = '𝐁𝐄𝐋𝐓𝐀𝐇-𝐌𝐃 𝐕𝟒.𝟎.𝟎 𝐋𝐀𝐓𝐄𝐒𝐓\n\nHello👋,Click on the link below and follow 𝐁𝐄𝐋𝐓𝐀𝐇-𝐌𝐃 WhatsApp Channel for updates on this bot and other Tech related informations\n';
    let d = '[https://whatsapp.com/channel/0029VaRHDBKKmCPKp9B2uH2F]\nMake sure you follow.Thank you\n\n\n> 𝐏𝐎𝐖𝐄𝐑𝐄𝐃 𝐁𝐘 𝐁𝐄𝐋𝐓𝐀𝐇 𝐓𝐄𝐂𝐇';
    let varmess = z + d;
    var img = 'https://telegra.ph/file/dcce2ddee6cc7597c859a.jpg';
    await zk.sendMessage(dest, { image: { url: img }, caption: varmess });
    //console.log("montest")
});
console.log("mon test");

zokou({ nomCom: "developer", reaction: "🌟", nomFichier: __filename }, async (dest, zk, commandeOptions) => {
    console.log("Commande saisie !!!s");
    let z = ' *HERE ARE MY OWNER INFO* \n\n✇ *NAME* : Brian Kanyiri Wainaina\n✇ *AGE* : 21 years\n✇ *SEX* : MALE\n✇ *RELIGION* : Christian\n✇ *NATIONALITY* :Kenyan 🇰🇪\n✇ *FAV TEAM* :Manchester United\n✇ *REAL LIFE* :I am a plumber, I never learned about coding.\n✇ *HOBBY* : Scrolling on websites\n✇ *CONTACT BELTAH* :👇 👇 \n';
    let d = '𓄂 https://wa.me/254114141192\n𓄂 https://wa.me/254737681758\n\n> *THANK YOU FOR LOVING BELTAH-MD*.\n> 𝐏𝐎𝐖𝐄𝐑𝐄𝐃 𝐁𝐘 𝐁𝐄𝐋𝐓𝐀𝐇 𝐓𝐄𝐂𝐇 ';
    let varmess = z + d;
    var img = 'https://telegra.ph/file/dcce2ddee6cc7597c859a.jpg';
    await zk.sendMessage(dest, { image: { url: img }, caption: varmess });
    //console.log("montest")
});
console.log("mon test");

zokou({ nomCom: "test", reaction: "✅", nomFichier: __filename }, async (dest, zk, commandeOptions) => {
    console.log("Commande saisie !!!s");
    let z = ' *☹︎ BELTAH-MD BOT IS CURRENTLY ACTIVE ☹︎*\n';
    let d = ' ❄︎ *_MADE ON EARTH BY BELTAH TECH TEAM_* ❄︎';
    let varmess = z + d;
    var img = 'https://telegra.ph/file/bc12002382105e156a9d1.mp4';
    await zk.sendMessage(dest, { image: { url: img }, caption: varmess });
    //console.log("montest")
});
console.log("mon test");

zokou({ nomCom: "bot", reaction: "🤖", nomFichier: __filename }, async (dest, zk, commandeOptions) => {
    console.log("Commande saisie !!!s");
    let z = ' *𝐁𝐄𝐋𝐓𝐀𝐇-𝐌𝐃 𝐕𝟒.𝟎.𝟎 𝐋𝐀𝐓𝐄𝐒𝐓 FEATURES* \n\n 1.Auto view status✅\n 2.Always online✅\n 3.A1 chat gpt enabled \n 4.Download songs/images✅\n 5.Open view once photos✅\n 6.Antidelete messages✅\n 7.Auto block contacts✅\n 8.Auto bluetick✅\n';
    let d = '>They can be turned on and off if you like\n\n*THANK YOU FOR LOVING BELTAH-MD*';
    let varmess = z + d;
    var img = 'https://telegra.ph/file/dcce2ddee6cc7597c859a.jpg';
    await zk.sendMessage(dest, { image: { url: img }, caption: varmess });
    //console.log("montest")
});
console.log("mon test");

zokou({ nomCom: "g*y", reaction: "🏳️‍🌈", nomFichier: __filename }, async (dest, zk, commandeOptions) => {
    console.log("Commande saisie !!!s");
    let z = ' *F*CK MEHN,,, THIS GUY IS G*Y🏳️‍🌈🏳️‍🌈🏳️‍🌈🏳️‍🌈*\n';
    let d = 'WHY WOULD YOU REQUEST THAT COMMAND IF NOT';
    let varmess = z + d;
    var img = 'https://telegra.ph/file/5d4c27c77b240483e7b05.png';
    await zk.sendMessage(dest, { image: { url: img }, caption: varmess });
    //console.log("montest")
});
console.log("mon test");

zokou({ nomCom: "check", reaction: "🗿", nomFichier: __filename }, async (dest, zk, commandeOptions) => {
    console.log("Commande saisie !!!s");
    let z = ' *BELTAH-MD UPDATES*\n\n';
    let d = 'Checking for updates...⏳\n\nUpdating new version...⏳\n\ndone....✅\n\n> *𝐁𝐄𝐋𝐓𝐀𝐇-𝐌𝐃 𝐕𝟒.𝟎.𝟎 𝐋𝐀𝐓𝐄𝐒𝐓 VERSION SUCCESSFULLY INSTALLED...* ';
    let varmess = z + d;
    var img = 'https://telegra.ph/file/dcce2ddee6cc7597c859a.jpg';
    await zk.sendMessage(dest, { image: { url: img }, caption: varmess });
    //console.log("montest")
});
console.log("mon test");

zokou({ nomCom: "version", reaction: "⏳", nomFichier: __filename }, async (dest, zk, commandeOptions) => {
    console.log("Commande saisie !!!s");
    let z = ' *YOU ARE CURRENTLY USING 𝐁𝐄𝐋𝐓𝐀𝐇-𝐌𝐃 𝐕𝟒.𝟎.𝟎 𝐋𝐀𝐓𝐄𝐒𝐓*\n\n';
    let d = '✅latest version installed...';
    let varmess = z + d;
    var img = 'https://telegra.ph/file/dcce2ddee6cc7597c859a.jpg';
    await zk.sendMessage(dest, { image: { url: img }, caption: varmess });
    //console.log("montest")
});
console.log("mon test");

zokou({ nomCom: "bugmenu", reaction: "🐛", nomFichier: __filename }, async (dest, zk, commandeOptions) => {
    console.log("Commande saisie !!!s");
    let z = '┌─❒𝗕𝗘𝗟𝗧𝗔𝗛-𝗠𝗗 𝗕𝗨𝗚 𝗠𝗘𝗡𝗨⁠⁠⁠⁠❒⁠⁠⁠\n│╭─────────────···\n┴│▸\n⬡│▸ ʙᴜɢ\n⬡│▸ ʙᴜɢᴠ\n⬡│▸ ʙᴜɢʀᴇᴀᴄᴛ\n⬡│▸ ᴀᴜᴅɪᴏʙᴜɢ\n⬡│▸ ɪᴏꜱʙᴜɢ\n⬡│▸ ɪᴏꜱʙᴜɢᴠ\n┬│▸\n│╰────────────···▸▸\n';
    let d = '└───────────────···▸';
    let varmess = z + d;
    var img = 'https://telegra.ph/file/e24fe04ebb2353c3c693e.jpg';
    await zk.sendMessage(dest, { image: { url: img }, caption: varmess });
    //console.log("montest")
});
console.log("mon test");

zokou({ nomCom: "genz", reaction: "🇰🇪", nomFichier: __filename }, async (dest, zk, commandeOptions) => {
    console.log("Commande saisie !!!s");
    let z = ' *❒⁠⁠⁠⁠ #REJECTFINANCEBILL2024 ❒⁠⁠⁠⁠*\n\nClick The link below to Join *❒⁠⁠⁠⁠GEN Z❒* official⁠⁠⁠⁠ WhatsApp Channel\nHelp us grow and reject that piece of shiet.\n\n';
    let d = 'https://whatsapp.com/channel/0029VaRHDBKKmCPKp9B2uH2F';
    let varmess = z + d;
    var img = 'https://telegra.ph/file/848e7f1f2b56721405cfc.jpg';
    await zk.sendMessage(dest, { image: { url: img }, caption: varmess });
    //console.log("montest")
});
console.log("mon test");
/*module.exports.commande = () => {
  var nomCom = ["test","t"]
  var reaction="☺️"
  return { nomCom, execute,reaction }
};

async function  execute  (origineMessage,zok) {
  console.log("Commande saisie !!!s")
   let z ='Salut je m\'appelle *Zokou* \n\n '+'je suis un bot Whatsapp Multi-appareil '
      let d =' developpé par *Djalega++*'
      let varmess=z+d
      var img='https://wallpapercave.com/uwp/uwp3842939.jpeg'
await  zok.sendMessage(origineMessage,  { image:{url:img},caption:varmess});
}  */ 
